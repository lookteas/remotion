import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {ganzhiTheme as C} from '../../../src/config/theme';
import {windowOpacity} from '../../../src/lib/anim';
import {captions} from './content';
import {ease} from './motion';
export const CaptionLayer=()=>{const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps,cue=captions.find(v=>t>=v.from&&t<v.to)||captions[captions.length-1];const alpha=cue.from===0||cue.from===60?1:windowOpacity(t,cue.from,cue.to,.22);return <AbsoluteFill style={{pointerEvents:'none',fontFamily:C.font,color:C.ivory}}>
 <div style={{position:'absolute',top:150,left:90,right:170,display:'flex',alignItems:'center',gap:22,color:C.gold,fontSize:27,letterSpacing:3}}><span style={{width:32,height:1,background:C.gold}}/>{cue.chapter}<span style={{marginLeft:'auto',fontFamily:C.numberFont,fontSize:23}}>{cue.index?`${cue.index} / 05`:''}</span></div>
 <div data-caption='main' style={{position:'absolute',top:237,left:90,width:860,fontSize:t>=35&&t<42?66:74,fontWeight:650,lineHeight:1.4,letterSpacing:1,opacity:alpha}}>{cue.lines.map((line,i)=><div key={line} style={{color:i===0?C.ivory:C.goldLight,opacity:t>=60&&i===1?ease(t,61.8,62.5):1}}>{line}</div>)}</div>
 <div data-caption='note' style={{position:'absolute',left:95,top:478,width:805,fontSize:35,lineHeight:1.6,color:C.secondary,opacity:alpha*ease(t,cue.from+.5,cue.from+1.1)}}>{cue.note}</div>
 <div style={{position:'absolute',left:90,top:1730,width:840,height:2,background:`${C.gold}22`}}><div style={{height:2,width:`${Math.min(100,t/66*100)}%`,background:C.gold}}/></div>
 <div style={{position:'absolute',left:90,top:1750,fontSize:21,color:C.muted,letterSpacing:3}}>天干地支 · 生活中的时间与祝愿</div>
 </AbsoluteFill>;};
