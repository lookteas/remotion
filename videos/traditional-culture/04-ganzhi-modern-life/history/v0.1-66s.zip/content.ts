export const captions = [
 {from:0,to:4,chapter:'生活里的时间',index:'01',lines:['马年，为什么','又写「丙午」？'],note:'一张贺卡里，藏着古老的时间记号。'},
 {from:4,to:13,chapter:'生肖贺卡',index:'01',lines:['挑张生肖贺卡，','就遇上了地支。'],note:'午，对应生肖马。'},
 {from:13,to:25,chapter:'入伏日期',index:'02',lines:['哪天入伏，','要数「庚」日。'],note:'从夏至起，数到第三个庚日。'},
 {from:25,to:35,chapter:'书画落款',index:'03',lines:['写幅字，','落款也会用干支。'],note:'记下创作的年与季。'},
 {from:35,to:42,chapter:'婚前合婚',index:'04',lines:['婚前，有些家庭','会看双方八字合不合。'],note:'出生信息排成八字，再作传统合婚比较。'},
 {from:42,to:49,chapter:'婚礼择日',index:'04',lines:['办婚礼，还会请人','挑个好日子。'],note:'传统习俗，寄托祝愿。'},
 {from:49,to:51,chapter:'婚礼筹备',index:'04',lines:['盼的是，','两个人和和美美。'],note:'传统习俗，寄托祝愿。'},
 {from:51,to:57,chapter:'乔迁择日',index:'05',lines:['搬新家，有些家庭','也会看日子。'],note:'按家里的习惯，安排入宅仪式。'},
 {from:57,to:60,chapter:'乔迁寄愿',index:'05',lines:['图个好意头，','盼安居顺遂。'],note:'民俗寄愿'},
 {from:60,to:66,chapter:'天干地支 · 今天',index:'',lines:['有些用来记时间，','有些用来寄托好盼头。'],note:''},
] as const;
export const fuDays=[{date:'6月25日',short:'06.25',name:'庚午',at:15},{date:'7月5日',short:'07.05',name:'庚辰',at:17},{date:'7月15日',short:'07.15',name:'庚寅',at:19}] as const;
