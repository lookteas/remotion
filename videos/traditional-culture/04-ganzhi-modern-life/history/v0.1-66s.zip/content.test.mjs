import {test} from 'node:test';
import assert from 'node:assert/strict';
import {existsSync, readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const ts=require('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,f);
const root=fileURLToPath(new URL('.',import.meta.url));
const read=name=>JSON.parse(readFileSync(`${root}/${name}`,'utf8'));
test('full video has seven adjacent sequences and five distinct life uses',()=>{
 assert.ok(existsSync(`${root}/timeline.json`),'episode timeline must exist');
 const timeline=read('timeline.json'),meta=read('video.json');
 let cursor=0;
 for(const s of timeline.scenes){assert.equal(s.from,cursor);cursor+=s.durationInFrames;}
 assert.equal(timeline.scenes.length,7);assert.equal(cursor,1980);assert.equal(cursor,meta.durationInFrames);
 assert.deepEqual(meta.format,{width:1080,height:1920,fps:30});
 assert.equal(meta.audio.narration,'');assert.equal(meta.audio.bgm,'');
});
test('Fu counting preserves earlier events and only produces the result at the third Geng day',()=>{
 assert.ok(existsSync(`${root}/motion.ts`),'episode motion implementation must exist');
 const {gengAt}=require(`${root}/motion.ts`);
 assert.equal(gengAt(14).count,0);assert.equal(gengAt(16.9).count,1);
 assert.equal(gengAt(18.9).count,2);assert.equal(gengAt(20.9).count,3);
 assert.equal(gengAt(20).result,false);assert.equal(gengAt(22).result,true);
 let previous=0;for(let f=390;f<750;f++){const v=gengAt(f/30);assert.ok(v.count>=previous);previous=v.count;}
});
test('persistent props keep continuous poses across every scene boundary',()=>{
 assert.ok(existsSync(`${root}/motion.ts`),'episode motion implementation must exist');
 const {posesAt}=require(`${root}/motion.ts`);
 for(const s of [4,13,25,35,42,49,51,60]){
  const a=posesAt(s-1/3000),b=posesAt(s+1/3000);
  for(const key of ['phone','calendar','art','box','camera'])for(const axis of ['x','y','scale','angle']){
   assert.ok(Number.isFinite(a[key][axis]));assert.ok(Math.abs(a[key][axis]-b[key][axis])<2,`${key}.${axis} jumps at ${s}`);
  }
 }
});
test('calendar leaves the portrait frame and the artwork descends into the box before travel',()=>{
 const {posesAt}=require(`${root}/motion.ts`);
 const c=posesAt(26).calendar;assert.ok(c.x-390*c.scale>1080,'old calendar must be fully outside the frame');
 const raised=posesAt(52).art,inserted=posesAt(53.5).art;
 assert.ok(raised.y<inserted.y-120,'scroll must descend into the opening');
 const travelling=posesAt(59);assert.ok(Math.abs(travelling.art.x-travelling.box.x)<100);
});
test('phone and day labels reveal information only after their matching events',()=>{
 const {phoneCalendarAt,gengAt}=require(`${root}/motion.ts`);
 assert.equal(typeof phoneCalendarAt,'function');
 assert.equal(phoneCalendarAt(16).result,false);assert.equal(phoneCalendarAt(22).saved,false);
 assert.equal(phoneCalendarAt(24).saved,true);
 for(const at of [15,17,19])assert.equal(gengAt(at+.01).count,[15,17,19].indexOf(at)+1);
});
test('brush follows cumulative segment length rather than vertex index',()=>{
 const {pointAlong}=require(`${root}/motion.ts`);assert.equal(typeof pointAlong,'function');
 assert.deepEqual(pointAlong([[0,0],[10,0],[110,0]],.5),{x:55,y:0});
});
test('phone stays below the three counted date labels during the Fu explanation',()=>{
 const {posesAt}=require(`${root}/motion.ts`);
 for(const t of [15,17,19,21]){const p=posesAt(t);assert.ok(p.phone.y-425*p.phone.scale>p.calendar.y+310*p.calendar.scale,'phone must not cover the date panel');}
});
test('scroll stays inside the closed box until extraction begins',()=>{
 const {posesAt}=require(`${root}/motion.ts`);
 for(const t of [54,56,58,59,59.9]){const p=posesAt(t);assert.ok(p.art.y-285*p.art.scale>p.box.y-195*p.box.scale,'scroll exposed through the closed lid');}
 const p=posesAt(60.8);assert.ok(p.art.y+330*p.art.scale<p.box.y-195*p.box.scale,'scroll must clear the silhouette before moving to front');
});
