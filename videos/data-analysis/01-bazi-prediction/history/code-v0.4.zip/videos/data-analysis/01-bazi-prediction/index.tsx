import {Sequence} from 'remotion';
import {BaziScene} from './Scenes';
import timeline from './timeline.json';

export const DURATION = timeline.scenes.reduce((sum, s) => sum + s.durationInFrames, 0);

/** Timing is authored from the versioned 30fps episode timeline. */
export default function BaziPrediction() {
  return <>
    <Sequence from={timeline.scenes[0].from} durationInFrames={timeline.scenes[0].durationInFrames} name="S01"><BaziScene scene={1}/></Sequence>
    <Sequence from={timeline.scenes[1].from} durationInFrames={timeline.scenes[1].durationInFrames} name="S02"><BaziScene scene={2}/></Sequence>
    <Sequence from={timeline.scenes[2].from} durationInFrames={timeline.scenes[2].durationInFrames} name="S03"><BaziScene scene={3}/></Sequence>
    <Sequence from={timeline.scenes[3].from} durationInFrames={timeline.scenes[3].durationInFrames} name="S04"><BaziScene scene={4}/></Sequence>
    <Sequence from={timeline.scenes[4].from} durationInFrames={timeline.scenes[4].durationInFrames} name="S05"><BaziScene scene={5}/></Sequence>
    <Sequence from={timeline.scenes[5].from} durationInFrames={timeline.scenes[5].durationInFrames} name="S06"><BaziScene scene={6}/></Sequence>
    <Sequence from={timeline.scenes[6].from} durationInFrames={timeline.scenes[6].durationInFrames} name="S07"><BaziScene scene={7}/></Sequence>
    <Sequence from={timeline.scenes[7].from} durationInFrames={timeline.scenes[7].durationInFrames} name="S08"><BaziScene scene={8}/></Sequence>
    <Sequence from={timeline.scenes[8].from} durationInFrames={timeline.scenes[8].durationInFrames} name="S09"><BaziScene scene={9}/></Sequence>
    <Sequence from={timeline.scenes[9].from} durationInFrames={timeline.scenes[9].durationInFrames} name="S10"><BaziScene scene={10}/></Sequence>
    <Sequence from={timeline.scenes[10].from} durationInFrames={timeline.scenes[10].durationInFrames} name="S11"><BaziScene scene={11}/></Sequence>
    <Sequence from={timeline.scenes[11].from} durationInFrames={timeline.scenes[11].durationInFrames} name="S12"><BaziScene scene={12}/></Sequence>
    <Sequence from={timeline.scenes[12].from} durationInFrames={timeline.scenes[12].durationInFrames} name="S13"><BaziScene scene={13}/></Sequence>
    <Sequence from={timeline.scenes[13].from} durationInFrames={timeline.scenes[13].durationInFrames} name="S14"><BaziScene scene={14}/></Sequence>
    <Sequence from={timeline.scenes[14].from} durationInFrames={timeline.scenes[14].durationInFrames} name="S15"><BaziScene scene={15}/></Sequence>
    <Sequence from={timeline.scenes[15].from} durationInFrames={timeline.scenes[15].durationInFrames} name="S16"><BaziScene scene={16}/></Sequence>
    <Sequence from={timeline.scenes[16].from} durationInFrames={timeline.scenes[16].durationInFrames} name="S17"><BaziScene scene={17}/></Sequence>
    <Sequence from={timeline.scenes[17].from} durationInFrames={timeline.scenes[17].durationInFrames} name="S18"><BaziScene scene={18}/></Sequence>
  </>;
}
