import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {staticFile} from 'remotion';
import {ichingTheme as C} from '../../../src/config/theme';
import {progress} from '../../../src/lib/anim';
import {FilmLook} from '../../../src/components/Backdrop';
import {Lift} from '../../../src/components/motion/Lift';
import content from './content.json';
import {Branching, Card, MatchMany, Prediction, QuoteMark, Records, SharedBirth} from './Artwork';

if (typeof document !== 'undefined') {
  void loadFont({family: 'BaziSerif', url: staticFile('fonts/bazi-prediction/NotoSerifSC-episode.woff2'), weight: '100 900'});
}

const highlight = (line: string, focus: string) => {
  const index = line.indexOf(focus);
  if (index < 0) return line;
  return <>{line.slice(0, index)}<span style={{color: C.goldLight}}>{focus}</span>{line.slice(index + focus.length)}</>;
};

export const BaziScene: React.FC<{scene: number}> = ({scene}) => {
  const frame = useCurrentFrame();
  const data = content[scene - 1];
  const immediate = [1, 16, 18].includes(scene);
  const conclusion = [4, 17].includes(scene);
  const bookend = scene === 1 || scene === 18;
  const opacity = scene === 18 ? 1 - progress(frame, 111, 9) : 1;
  let art: React.ReactNode;
  switch (scene) {
    case 1: case 18: art = <SharedBirth frame={frame} ending={scene === 18}/>; break;
    case 2: art = <SharedBirth frame={frame} definition/>; break;
    case 3: art = <Branching frame={frame}/>; break;
    case 4: art = <g opacity={0.08}><Branching frame={60} label={false}/></g>; break;
    case 5: case 6: case 12: case 13: case 15: art = <Prediction frame={frame} stage={scene}/>; break;
    case 7: art = <g opacity={progress(frame, 0, 18)}><Card y={180} height={320}/><QuoteMark/></g>; break;
    case 8: art = <><QuoteMark/><text x={416} y={570} textAnchor="middle" fill={C.secondary} fontSize={36}>{data.labels[0]}</text></>; break;
    case 9: art = <MatchMany frame={frame}/>; break;
    case 10: case 11: art = <Records frame={frame} restore={scene === 11}/>; break;
    case 14: art = <><Card y={100} height={190}/><Card y={370} height={190}/><path d="M416 305 V350 M406 340 L416 350 L426 340" stroke={C.gold} strokeWidth={2} fill="none"/><text x={416} y={640} textAnchor="middle" fill={C.secondary} fontSize={36}>{data.labels[0]}</text></>; break;
    case 16: art = <Records frame={24} compare/>; break;
    default: art = null;
  }
  const text = scene === 14 ? <div data-main-text style={{fontSize: 58, lineHeight: 1.5, textAlign: 'center', fontWeight: 500}}>
    <div style={{position: 'absolute', top: 550, width: '100%'}}>{data.lines[0]}</div>
    <div style={{position: 'absolute', top: 779, width: '100%'}}>{data.lines.slice(1).map((line, i) => <div key={i}>{highlight(line, data.focus)}</div>)}</div>
  </div> : <div data-main-text style={{fontSize: bookend ? 72 : conclusion ? 72 : 64, lineHeight: 1.5, fontWeight: 500, textAlign: 'center', letterSpacing: 0}}>
    {data.lines.map((line, i) => <div key={i} style={{whiteSpace: 'nowrap'}}>{highlight(line, data.focus)}</div>)}
  </div>;
  return <AbsoluteFill style={{backgroundColor: C.ink, color: C.ivory, fontFamily: 'BaziSerif', overflow: 'hidden'}}>
    <AbsoluteFill style={{background: `radial-gradient(ellipse at 46% 37%, ${C.gold}12 0%, transparent 49%)`}}/>
    <FilmLook grain={0.025} vignette={0.38}/>
    <AbsoluteFill style={{opacity}}>
      <div style={{position: 'absolute', left: 88, top: 230, width: 832, height: 1, background: `linear-gradient(90deg, transparent, ${C.gold}55, transparent)`}}/>
      <svg viewBox="0 0 832 720" width={832} height={720} style={{position: 'absolute', left: 88, top: bookend ? 740 : conclusion ? 320 : 400, overflow: 'visible'}}>{art}</svg>
      <div style={{position: 'absolute', left: 88, width: 832, top: scene === 14 ? 0 : bookend ? 400 : conclusion ? 820 : 1210}}>
        {immediate ? text : <Lift at={0} duration={12} distance={0} style={scene === 14 ? {overflow: 'visible'} : undefined}>{text}</Lift>}
      </div>
      <div style={{position: 'absolute', left: 430, top: 1640, width: 148, height: 2, backgroundColor: C.gold, opacity: 0.4}}/>
    </AbsoluteFill>
  </AbsoluteFill>;
};
