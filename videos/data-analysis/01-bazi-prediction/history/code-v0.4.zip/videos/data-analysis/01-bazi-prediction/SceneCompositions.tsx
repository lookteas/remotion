import {Composition, Folder} from 'remotion';
import {BaziScene} from './Scenes';

export const BaziSceneCompositions = () => <Folder name="Bazi-scenes">
  <Composition id="bazi-s01" component={BaziScene} defaultProps={{scene: 1}} durationInFrames={120} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s02" component={BaziScene} defaultProps={{scene: 2}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s03" component={BaziScene} defaultProps={{scene: 3}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s04" component={BaziScene} defaultProps={{scene: 4}} durationInFrames={120} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s05" component={BaziScene} defaultProps={{scene: 5}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s06" component={BaziScene} defaultProps={{scene: 6}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s07" component={BaziScene} defaultProps={{scene: 7}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s08" component={BaziScene} defaultProps={{scene: 8}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s09" component={BaziScene} defaultProps={{scene: 9}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s10" component={BaziScene} defaultProps={{scene: 10}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s11" component={BaziScene} defaultProps={{scene: 11}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s12" component={BaziScene} defaultProps={{scene: 12}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s13" component={BaziScene} defaultProps={{scene: 13}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s14" component={BaziScene} defaultProps={{scene: 14}} durationInFrames={180} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s15" component={BaziScene} defaultProps={{scene: 15}} durationInFrames={180} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s16" component={BaziScene} defaultProps={{scene: 16}} durationInFrames={180} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s17" component={BaziScene} defaultProps={{scene: 17}} durationInFrames={150} width={1080} height={1920} fps={30}/>
  <Composition id="bazi-s18" component={BaziScene} defaultProps={{scene: 18}} durationInFrames={120} width={1080} height={1920} fps={30}/>
</Folder>;
