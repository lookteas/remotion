import React from 'react';
import {ichingTheme as C} from '../../../src/config/theme';
import {progress} from '../../../src/lib/anim';
import content from './content.json';

const labelFor = (scene: number, index = 0) => content[scene - 1].labels[index];

/** Episode diagrams use one 832×720 coordinate system; no statistical data. */
const Trace: React.FC<{d: string; reveal?: number; color?: string; opacity?: number}> = ({d, reveal = 1, color = C.gold, opacity = 1}) =>
  <path d={d} fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - reveal} opacity={opacity} />;

export const Person = ({x, y, scale = 1, opacity = 1}: {x: number; y: number; scale?: number; opacity?: number}) => <g transform={`translate(${x} ${y}) scale(${scale})`} opacity={opacity}>
  <circle cy={-32} r={17} fill={C.ivory} />
  <path d="M-32 39 V12 Q-32 -6 -12 -6 H12 Q32 -6 32 12 V39" fill={`${C.gold}24`} stroke={C.gold} strokeWidth={2.5} />
  <path d="M-16 39 V73 M16 39 V73" stroke={C.gold} strokeWidth={3} strokeLinecap="round" />
</g>;

export const EightCells = ({x = 416, y = 170, split = 0}: {x?: number; y?: number; split?: number}) => <g transform={`translate(${x} ${y})`}>
  {Array.from({length: 8}, (_, i) => {
    const pair = Math.floor(i / 2);
    const cx = (pair - 1.5) * (100 + split * 24);
    const cy = (i % 2) * 66;
    return <g key={i} transform={`translate(${cx} ${cy})`}>
      <rect x={-32} y={-28} width={64} height={56} rx={3} fill={`${C.gold}0C`} stroke={C.gold} strokeWidth={2} />
      <path d="M-13 -7 H13 M-13 7 H13" stroke={C.goldLight} strokeWidth={3} opacity={0.75} />
    </g>;
  })}
</g>;

const Label = ({children, x = 416, y, color = C.secondary, size = 36}: {children: React.ReactNode; x?: number; y: number; color?: string; size?: number}) =>
  <text x={x} y={y} textAnchor="middle" fill={color} fontSize={size} fontWeight={500}>{children}</text>;

const Book = ({x, y}: {x: number; y: number}) => <g transform={`translate(${x} ${y})`} fill="none" stroke={C.gold} strokeWidth={2.5}>
  <path d="M0 -35 Q-26 -48 -60 -35 V45 Q-25 32 0 45 Q25 32 60 45 V-35 Q25 -48 0 -35 V45" />
  <path d="M-46 -15 L-14 -12 M-46 0 L-14 3 M14 -12 L46 -15 M14 3 L46 0" opacity={0.5} />
</g>;
const House = ({x, y}: {x: number; y: number}) => <g transform={`translate(${x} ${y})`} fill="none" stroke={C.gold} strokeWidth={2.5}>
  <path d="M-60 -5 L0 -52 L60 -5 M-44 -15 V48 H44 V-15 M-12 48 V10 H12 V48" />
</g>;

export const SharedBirth = ({frame, definition = false, ending = false}: {frame: number; definition?: boolean; ending?: boolean}) => <>
  <ellipse cx={416} cy={270} rx={290} ry={165} fill="none" stroke={C.gold} strokeWidth={1} opacity={0.12} />
  <EightCells y={definition ? 270 : 170} split={definition ? progress(frame, 0, 24) : 0} />
  {definition ? <>{[0, 1, 2, 3].map(i => <circle key={i} cx={230 + i * 124} cy={390} r={4} fill={C.goldLight} opacity={progress(frame, i * 5, 9)} />)}</> : <>
    <Trace d="M416 275 C416 350 232 320 232 427" reveal={ending ? 1 : progress(frame, 0, 18)} />
    <Trace d="M416 275 C416 350 600 320 600 427" reveal={ending ? 1 : progress(frame, 0, 18)} />
    <Person x={232} y={480} scale={1.25} /><Person x={600} y={480} scale={1.25} />
    <circle cx={416} cy={275} r={5} fill={C.goldLight} />
  </>}
</>;

export const Branching = ({frame, label = true}: {frame: number; label?: boolean}) => <>
  <EightCells y={80} />
  {[180, 416, 652].map((x, i) => <g key={x}>
    <Trace d={`M416 190 C416 290 ${x} 230 ${x} 340`} reveal={progress(frame, i * 8, 30)} />
    <g opacity={progress(frame, 16 + i * 8, 16)}><Person x={x} y={380} scale={0.8} /></g>
    <Trace d={`M${x} 442 V525`} reveal={progress(frame, 35 + i * 5, 15)} />
    <g opacity={progress(frame, 40 + i * 5, 10)}>
      {i === 0 ? <House x={x} y={590} /> : i === 1 ? <Book x={x} y={590} /> : <Trace d={`M${x - 50} 625 C${x - 50} 560 ${x + 50} 610 ${x + 50} 550`} />}
    </g>
  </g>)}
  {label && <Label y={710}>{labelFor(3)}</Label>}
</>;

export const Card = ({x = 96, y = 120, width = 640, height = 350, children, opacity = 1}: {x?: number; y?: number; width?: number; height?: number; children?: React.ReactNode; opacity?: number}) => <g opacity={opacity}>
  <rect x={x} y={y} width={width} height={height} rx={5} fill={C.surface} stroke={`${C.gold}90`} strokeWidth={2} />
  <path d={`M${x + 22} ${y} H${x} V${y + 22} M${x + width - 22} ${y + height} H${x + width} V${y + height - 22}`} stroke={C.goldLight} fill="none" strokeWidth={3} />
  {children}
</g>;

const BlankLines = ({x, y, width, rows = 3}: {x: number; y: number; width: number; rows?: number}) => <>
  {Array.from({length: rows}, (_, i) => <path key={i} d={`M${x} ${y + i * 53} H${x + width * (i === rows - 1 ? 0.65 : 1)}`} stroke={C.ivory} strokeWidth={2} opacity={0.18} />)}
</>;

export const Prediction = ({frame, stage}: {frame: number; stage: number}) => {
  const p = progress(frame, 0, 18);
  if (stage === 6) return <g opacity={p}>
    {[130, 410].map((y, i) => <Card key={y} y={y} height={210}><Label y={y + 64} size={44} color={C.goldLight}>{labelFor(6, i)}</Label><BlankLines x={156} y={y + 113} width={510} rows={2} /></Card>)}
  </g>;
  if (stage === 15) return <g opacity={p}>
    <Card y={110} height={460}>
      <Label y={245} size={48} color={C.goldLight}>{labelFor(15)}</Label><Label y={365} size={48}>{labelFor(15, 1)}</Label>
      <path d="M176 290 H656" stroke={C.gold} opacity={0.25} />
      <g transform="translate(416 460)" fill="none" stroke={C.goldLight} strokeWidth={3}><rect x={-23} y={-8} width={46} height={38} rx={4}/><path d="M-14 -8 V-20 A14 14 0 0 1 14 -20 V-8"/><circle cy={9} r={3} fill={C.goldLight}/></g>
    </Card><Label y={640}>{labelFor(15, 2)}</Label>
  </g>;
  return <g opacity={p} transform={`translate(0 ${(1 - p) * 16})`}>
    <Card y={160} height={360}>
      <circle cx={158} cy={219} r={9} fill={C.gold} opacity={0.8} />
      <path d="M190 219 H352" stroke={C.gold} strokeWidth={2} opacity={0.5} />
      {[0, 1, 2].map(i => <g key={i} opacity={stage === 13 ? 0.3 + progress(frame, i * 6, 12) * 0.7 : 0.7}><rect x={148} y={274 + i * 62} width={25} height={25} fill="none" stroke={C.gold} /><path d={`M199 ${287 + i * 62} H675`} stroke={C.ivory} opacity={0.3} /></g>)}
    </Card>{stage === 12 && <Label y={606} color={C.goldLight}>{labelFor(12)}</Label>}
  </g>;
};

export const MatchMany = ({frame}: {frame: number}) => <>
  <Card x={256} y={50} width={320} height={145}><BlankLines x={300} y={95} width={225} rows={2} /></Card>
  {[140, 324, 508, 692].map((x, i) => <g key={x}>
    <Trace d={`M416 195 C416 310 ${x} 320 ${x} 440`} reveal={progress(frame, i * 7, 35)} />
    <Person x={x} y={510} scale={0.9} opacity={progress(frame, 20 + i * 7, 18)} />
  </g>)}<Label y={675}>{labelFor(9)}</Label>
</>;

export const Records = ({frame, restore = false, compare = false}: {frame: number; restore?: boolean; compare?: boolean}) => <>
  {(compare ? [115, 400] : [180]).map((y, group) => <Card key={y} x={56} y={y} width={720} height={compare ? 230 : 350}>
    {[0, 1, 2, 3, 4, 5].map(i => {
      const hit = i % 2 === 0;
      const x = 104 + i * 113;
      const opacity = compare ? 1 : restore && !hit ? 0.15 + progress(frame, 0, 24) * 0.85 : progress(frame, i * 2, 14);
      return <g key={i} opacity={opacity}>
        <rect x={x} y={y + 65} width={74} height={118} rx={2} fill="none" stroke={hit ? C.gold : C.vermilion} strokeWidth={2}/>
        {hit ? <circle cx={x + 37} cy={y + 102} r={10} fill="none" stroke={C.goldLight} strokeWidth={3}/> : <path d={`M${x + 28} ${y + 93} l18 18 m0 -18 l-18 18`} stroke={C.vermilion} strokeWidth={3}/>}
        <path d={`M${x + 16} ${y + 139} h42 m-42 15 h28`} stroke={C.ivory} opacity={0.25}/>
      </g>;
    })}
    {!compare && <><Label x={260} y={y + 280} color={C.goldLight}>{labelFor(10)}</Label><Label x={580} y={y + 280} color={C.vermilion}>{labelFor(10, 1)}</Label></>}
    {compare && group === 0 && <Trace d="M416 345 V400" opacity={0.4}/>}
  </Card>)}<Label y={compare ? 690 : 625}>{labelFor(16)}</Label>
</>;

export const QuoteMark = () => <g fill="none" stroke={C.gold} opacity={0.5} strokeWidth={3}>
  <path d="M285 280 Q245 310 245 365 H290 V315 H263 M405 280 Q365 310 365 365 H410 V315 H383" />
  <path d="M230 430 H602" strokeWidth={1} opacity={0.6}/>
</g>;
