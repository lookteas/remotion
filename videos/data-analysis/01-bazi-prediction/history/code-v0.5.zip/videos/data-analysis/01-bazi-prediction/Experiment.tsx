import React from 'react';
import {baziTheme as C} from '../../../src/config/theme';
import {lerp, progress} from '../../../src/lib/anim';
import {settle} from '../../../src/lib/physical-motion';
import {BirthSeal, Block, Book, Burst, Envelope, Figure, Lock, Paper} from './Props';
import {Place, StageLabel} from './Stage';
import {LifeWorlds} from './Opening';
import content from './content.json';

export const SealPrediction = ({frame}: {frame: number}) => {
  const insert = progress(frame, 48, 45); const closed = progress(frame, 93, 23);
  return <>
    <Place y={950} rx={15} z={0}><Book size={630} open={progress(frame, 0, 35)}/></Place>
    <Place x={480} y={lerp(600, 850, insert)} scale={0.95 - insert * 0.25} rotate={-7} opacity={1 - progress(frame, 87, 14)} z={2}><Paper w={390} h={440}/></Place>
    <StageLabel x={480} y={300} opacity={1 - progress(frame, 87, 14)}>{content[7].labels[0]}</StageLabel>
    <Place x={480} y={890} rotate={-7} z={3}><Envelope w={490} close={closed}/></Place>
    <StageLabel x={480} y={1220} opacity={closed}>{content[7].labels[1]}</StageLabel>
    <Place x={790} y={660} scale={0.7} opacity={progress(frame, 140, 28)} rotate={10} z={1}><Paper w={270} h={320}/></Place>
    <StageLabel x={790} y={490} opacity={progress(frame, 140, 28)}>{content[7].labels[2]}</StageLabel>
    <Place x={820} y={1050} opacity={progress(frame, 120, 20)} z={4}><svg width={160} height={160} viewBox="0 0 160 160"><circle cx={80} cy={80} r={70} fill={C.bronzeDark} stroke={C.gold} strokeWidth={5}/>{Array.from({length: 12}, (_, i) => <path key={i} d="M80 18 V27" stroke={C.goldLight} strokeWidth={3} transform={`rotate(${i * 30} 80 80)`}/>)}<path d="M80 80 V35" stroke={C.goldLight} strokeWidth={4} transform={`rotate(${progress(frame, 125, 65) * 270} 80 80)`}/><circle cx={80} cy={80} r={5} fill={C.goldLight}/></svg></Place>
    <Burst frame={frame} at={110} x={480} y={885} count={20}/>
  </>;
};

export const SpecificPrediction = ({frame}: {frame: number}) => {
  const flip = progress(frame, 84, 32);
  return <>
    <Place y={800} ry={Math.sin(flip * Math.PI) * 85} rotate={lerp(-8, 0, flip)} scale={1.12}>
      <Paper w={650} h={510} style={{boxShadow: `0 0 ${35 * (1 - flip)}px ${C.paper}44, 6px 8px 0 ${C.paperEdge}, 0 40px 70px ${C.black}88`}}><div style={{position: 'absolute', left: 55, right: 55, top: 85, height: 1, background: C.bronze}}/></Paper>
    </Place>
    <Place x={290} y={1120} scale={settle(frame, 112) * 0.7} rotate={-12} z={3}>
      <Block w={210} h={190} paper><div style={{height: 45, background: C.vermilion}}/>
        <div style={{display: 'flex', flexWrap: 'wrap', gap: 12, padding: 20}}>{Array.from({length: 7}, (_, i) => <div key={i} style={{width: 27, height: 30, background: C.paperEdge, opacity: 0.75}}/>)}</div>
      </Block>
    </Place>
    <Place x={790} y={1100} scale={settle(frame, 126) * 0.6} rotate={12} z={3}><Paper w={230} h={280}/></Place>
    <StageLabel y={1270} size={36}>{content[8].labels[0]}</StageLabel>
  </>;
};

export const Decision = ({frame}: {frame: number}) => {
  const lock = progress(frame, 120, 40);
  return <>
    {[0, 1].map(i => {
      const p = settle(frame, i ? 80 : 42, 30, 14, 160);
      return <React.Fragment key={i}>
        <Place y={620 + i * 450} rx={18}><Block w={730} h={260} d={30}><div style={{position: 'absolute', inset: 20, background: C.bronzeDark, border: `1px solid ${C.gold}66`}}/></Block></Place>
        <StageLabel x={650} y={570 + i * 450} size={50} color={i ? C.goldLight : C.secondary}>{content[9].labels[i]}</StageLabel>
        <Place x={310} y={490 + i * 450 + p * 110} rotate={-8 + (1 - p) * 30} scale={0.53} opacity={progress(frame, i ? 80 : 42, 12)} z={4}><Paper w={280} h={300} mark={i && frame > 110 ? 'hit' : 'miss'}/></Place>
      </React.Fragment>;
    })}
    <div style={{position: 'absolute', left: 529, top: 745, height: 180, width: 18, background: `linear-gradient(90deg, ${C.bronze}, ${C.goldLight}, ${C.bronze})`, opacity: lock}}/>
    <Place y={840} scale={Math.max(0.01, settle(frame, 130))} z={8}><Lock closed={progress(frame, 138, 20)} size={115}/></Place>
    <StageLabel y={1270} size={36}>{content[9].labels[2]}</StageLabel><Burst frame={frame} at={151} y={880}/>
  </>;
};

export const Compare = ({frame}: {frame: number}) => <>
  {[0, 1].map(i => <React.Fragment key={i}>
    <Place y={620 + i * 390} rx={18}><Block w={730} h={240} d={30}><div style={{position: 'absolute', inset: 22, background: C.surface}}/></Block></Place>
    <StageLabel x={350} y={440 + i * 390} size={43}>{content[10].labels[i]}</StageLabel>
    {[0, 1, 2].map(j => {
      const p = progress(frame, j * 12, 50); const seal = progress(frame, 68 + j * 7, 25);
      const collect = progress(frame, 130 + j * 8, 35);
      return <React.Fragment key={j}>
        <Place x={lerp(150, 310 + j * 210, p)} y={lerp(520 + i * 390, 610 + i * 390, p)} scale={0.36} rotate={(1 - p) * -30} opacity={p * (1 - seal)} z={2}><Paper w={280} h={290}/></Place>
        <Place x={310 + j * 210} y={610 + i * 390 + collect * 15} scale={0.48} opacity={progress(frame, 48 + j * 7, 18)} z={4}><Envelope w={350} close={seal}/></Place>
      </React.Fragment>;
    })}
  </React.Fragment>)}
  <Place x={870} y={810} scale={0.6}><Lock size={120}/></Place>
  <StageLabel y={1250} size={36}>{content[10].labels[2]}</StageLabel>
</>;

export const Finale = ({frame}: {frame: number}) => {
  const back = progress(frame, 114, 40);
  return <>
    <div style={{opacity: 1 - back}}>
      <Place y={980} scale={0.8 + progress(frame, 0, 90) * 0.2}><Book size={550} open={1 - progress(frame, 35, 50)}/></Place>
      {Array.from({length: 7}, (_, i) => {
        const p = progress(frame, i * 5, 50);
        return <Place key={i} x={lerp(120 + i * 140, 540, p)} y={lerp(650 + (i % 2) * 200, 980, p)} scale={lerp(0.4, 0.08, p)} rotate={(1 - p) * (i - 3) * 25} opacity={1 - p}><Paper w={280} h={320}/></Place>;
      })}
    </div>
    <div style={{opacity: back * 0.24}}><LifeWorlds frame={200}/></div>
    {[0, 1].map(i => <Place key={i} x={i ? 740 : 340} y={990} scale={back} z={5}><Figure size={220} variant={i}/></Place>)}
    <Place y={650} scale={back} z={6}><BirthSeal size={370}/></Place>
  </>;
};
