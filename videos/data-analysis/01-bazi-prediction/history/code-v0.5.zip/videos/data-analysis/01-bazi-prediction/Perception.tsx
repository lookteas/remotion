import React from 'react';
import {baziTheme as C} from '../../../src/config/theme';
import {lerp, progress, rand} from '../../../src/lib/anim';
import {Paper, Figure, Book, Burst} from './Props';
import {Place, CameraRig, StageLabel} from './Stage';
import content from './content.json';

export const ManyPeople = ({frame}: {frame: number}) => {
  const reveal = progress(frame, 100, 55);
  return <>
    {Array.from({length: 7}, (_, i) => {
      const row = i < 3 ? 0 : 1;
      const x = row ? 200 + (i - 3) * 225 : 270 + i * 270;
      const y = row ? 1060 : 730;
      const p = progress(frame, 105 + i * 5, 35);
      return <React.Fragment key={i}>
        <Place x={x} y={y + 30 * (1 - reveal)} scale={row ? 0.8 : 0.65} opacity={reveal} z={row ? 2 : 0}><Figure size={180} variant={i}/></Place>
        <Place x={lerp(540, x - 12, p)} y={lerp(720, y - 120, p)} scale={lerp(0.8, 0.3, p)} rotate={lerp((i - 3) * 2, (i - 3) * 5, p)} ry={Math.sin(p * Math.PI) * 45} opacity={p} z={3}><Paper w={340} h={270}/></Place>
      </React.Fragment>;
    })}
    <Place y={710} scale={1.45 - reveal} rotate={-4 + Math.sin(frame / 40) * 2} ry={10 + Math.sin(frame / 50) * 5} opacity={1 - reveal} z={5}><Paper w={500} h={440}><div style={{position: 'absolute', top: 70, left: 65, color: C.bronze, fontSize: 155, lineHeight: 1}}>“</div><div style={{position: 'absolute', left: 90, right: 90, top: 245, height: 3, background: C.bronze, opacity: 0.3}}/></Paper></Place>
    <StageLabel y={1250} size={36}>{content[4].labels[0]}</StageLabel>
  </>;
};

/** Same world positions for B06/B07: the pullback reveals records that already existed. */
const RecordWorld = ({frame, gather = 0, visible = 1}: {frame: number; gather?: number; visible?: number}) => <>
  {Array.from({length: 15}, (_, i) => {
    const col = i % 5; const row = Math.floor(i / 5);
    const hit = i % 3 === 0;
    const tx = 140 + col * 200; const ty = 550 + row * 245;
    const p = progress(frame, 50 + i * 3, 42) * gather;
    return <Place key={i} x={lerp(tx, 540 + (i % 3) * 3, p)} y={lerp(ty, 1000 - i * 2, p)} scale={lerp(0.52, 0.65, p)} rotate={lerp((rand(i, 4) - 0.5) * 30, -7, p)} rx={p * 50} opacity={hit ? 1 : visible} z={i + 1}>
      <Paper w={280} h={340} mark={hit ? 'hit' : 'miss'}/>
    </Place>;
  })}
</>;

export const SelectiveMemory = ({frame}: {frame: number}) => {
  const reveal = progress(frame, 150, 80);
  return <>
    <div style={{position: 'absolute', left: 30, top: 300, width: 1000, height: 1000, background: `radial-gradient(ellipse at 44% 45%, ${C.gold}35, transparent 65%)`, transform: `translateX(${reveal * 110}px)`}}/>
    <div style={{position: 'absolute', inset: 0, clipPath: 'inset(230px 0 740px 0)'}}><CameraRig frame={frame} keys={[{at: 0, x: 140, y: 550, scale: 1.35}, {at: 95, x: 140, y: 550, scale: 2.05}, {at: 140, x: 140, y: 550, scale: 2.05}, {at: 239, x: 210, y: 620, scale: 1.6}]}>
      <RecordWorld frame={0} visible={0.07 + reveal * 0.24}/>
    </CameraRig></div>
    <StageLabel x={300} y={1190}>{content[5].labels[0]}</StageLabel><StageLabel x={750} y={1190} opacity={reveal} color={C.vermilion}>{content[5].labels[1]}</StageLabel>
    <StageLabel y={1270} size={34}>{content[5].labels[2]}</StageLabel>
  </>;
};

export const FullRecord = ({frame}: {frame: number}) => {
  const gather = progress(frame, 100, 65);
  return <>
    <div style={{position: 'absolute', inset: 0, clipPath: 'inset(230px 0 740px 0)'}}><CameraRig frame={frame} keys={[{at: 0, x: 210, y: 620, scale: 1.6}, {at: 45, x: 540, y: 820, scale: 0.94}, {at: 110, x: 540, y: 820, scale: 0.94}, {at: 200, x: 540, y: 820, scale: 1}]}>
      <Place y={1010} opacity={progress(frame, 110, 25)} z={0}><Book open={1 - progress(frame, 190, 28)} size={550}/></Place>
      <div style={{opacity: 1 - progress(frame, 180, 35)}}><RecordWorld frame={frame} gather={gather} visible={0.31 + progress(frame, 0, 40) * 0.69}/></div>
    </CameraRig></div>
    <StageLabel x={280} y={1200} opacity={1 - gather}>{content[6].labels[0]}</StageLabel><StageLabel x={780} y={1200} color={C.vermilion} opacity={1 - gather}>{content[6].labels[1]}</StageLabel>
    <StageLabel y={1280} size={34}>{content[6].labels[2]}</StageLabel><Burst frame={frame} at={210} y={1120}/>
  </>;
};
