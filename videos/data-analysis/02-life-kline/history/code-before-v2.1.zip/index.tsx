import {AbsoluteFill, Sequence} from 'remotion';
import {lifeKlineTheme as C} from '../../../src/config/theme';
import {ContinuousWorld} from './ContinuousWorld';
import {Effects, FundamentalLabel, Narrative} from './Scenes';
import content from './content.json';
import timeline from './timeline.json';

export const DURATION=timeline.scenes.reduce((sum,s)=>sum+s.durationInFrames,0);
export default function LifeKline(){
  return <AbsoluteFill style={{background:C.bg,fontFamily:C.font,overflow:'hidden'}}>
    <Sequence from={0} durationInFrames={1320} name="连续世界 · 下坠到重构"><ContinuousWorld/></Sequence>
    <Sequence from={0} durationInFrames={150} name="K01 人生急坠"><Narrative scene={0}/></Sequence>
    <Sequence from={150} durationInFrames={180} name="K02 碎片中的筑底"><Narrative scene={1}/></Sequence>
    <Sequence from={330} durationInFrames={120} name="K03 碎片汇聚基本面"><Narrative scene={2}/></Sequence>
    <Sequence from={450} durationInFrames={870} name="K04 身体 · 稳定后持续保留"><FundamentalLabel index={0}/></Sequence>
    <Sequence from={630} durationInFrames={690} name="K05 技能 · 接入后持续保留"><FundamentalLabel index={1}/></Sequence>
    <Sequence from={810} durationInFrames={510} name="K06 现金流 · 蓄积后持续保留"><FundamentalLabel index={2}/></Sequence>
    <Sequence from={990} durationInFrames={150} name="K07 机会逼近"><Narrative scene={6}/></Sequence>
    <Sequence from={1140} durationInFrames={180} name="K08 把选择交还给你"><Narrative scene={7}/></Sequence>
    <Effects/>
    <div style={{position:'absolute',left:90,top:130,color:C.secondary,fontSize:28,letterSpacing:1}}>{content.disclosure}</div>
  </AbsoluteFill>;
}
