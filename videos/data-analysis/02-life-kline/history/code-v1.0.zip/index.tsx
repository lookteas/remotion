import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {lifeKlineTheme as C} from '../../../src/config/theme';
import {Atmosphere} from './Artwork';
import {LifeScene} from './Scenes';
import content from './content.json';
import timeline from './timeline.json';

export const DURATION=timeline.scenes.reduce((sum,s)=>sum+s.durationInFrames,0);
export default function LifeKline(){
  const frame=useCurrentFrame();
  const scene=timeline.scenes.findIndex(s=>frame>=s.from&&frame<s.from+s.durationInFrames);
  return <AbsoluteFill style={{background:C.bg,fontFamily:C.font,overflow:'hidden'}}>
    <Atmosphere frame={frame}/>
    <Sequence from={timeline.scenes[0].from} durationInFrames={timeline.scenes[0].durationInFrames} name="K01 人生急坠"><LifeScene scene={0}/></Sequence>
    <Sequence from={timeline.scenes[1].from} durationInFrames={timeline.scenes[1].durationInFrames} name="K02 低点之下"><LifeScene scene={1}/></Sequence>
    <Sequence from={timeline.scenes[2].from} durationInFrames={timeline.scenes[2].durationInFrames} name="K03 展开基本面"><LifeScene scene={2}/></Sequence>
    <Sequence from={timeline.scenes[3].from} durationInFrames={timeline.scenes[3].durationInFrames} name="K04 身体"><LifeScene scene={3}/></Sequence>
    <Sequence from={timeline.scenes[4].from} durationInFrames={timeline.scenes[4].durationInFrames} name="K05 技能"><LifeScene scene={4}/></Sequence>
    <Sequence from={timeline.scenes[5].from} durationInFrames={timeline.scenes[5].durationInFrames} name="K06 现金流"><LifeScene scene={5}/></Sequence>
    <Sequence from={timeline.scenes[6].from} durationInFrames={timeline.scenes[6].durationInFrames} name="K07 机会逼近"><LifeScene scene={6}/></Sequence>
    <Sequence from={timeline.scenes[7].from} durationInFrames={timeline.scenes[7].durationInFrames} name="K08 抄底自己"><LifeScene scene={7}/></Sequence>
    <div style={{position:'absolute',left:90,right:150,top:130,display:'flex',justifyContent:'space-between',alignItems:'center',color:C.secondary,fontSize:30,letterSpacing:3}}><span>人生K线</span><span style={{fontFamily:C.numberFont,fontSize:24,color:C.muted}}>{String(scene+1).padStart(2,'0')} / 08</span></div>
    <div style={{position:'absolute',left:90,top:192,color:C.muted,fontSize:30,letterSpacing:1}}>{content.disclosure}</div>
    <div style={{position:'absolute',left:90,right:150,bottom:200,height:2,background:C.surface}}><div style={{height:2,width:`${frame/(DURATION-1)*100}%`,background:C.blue,opacity:.6}}/></div>
  </AbsoluteFill>;
}
