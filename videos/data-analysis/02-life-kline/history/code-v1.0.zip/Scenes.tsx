import React from 'react';
import {loadFont} from '@remotion/fonts';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {lifeKlineTheme as C} from '../../../src/config/theme';
import {progress} from '../../../src/lib/anim';
import {Lift} from '../../../src/components/motion/Lift';
import {LifeArtwork} from './Artwork';
import content from './content.json';
import timeline from './timeline.json';

if (typeof document !== 'undefined') void loadFont({family:'LifeKlineSans',url:staticFile('fonts/life-kline/NotoSansSC-life-kline.woff2'),weight:'100 900'});

const Emphasis: React.FC<{line:string; focus:string}> = ({line,focus}) => {
  const at=line.indexOf(focus);
  return at<0?<>{line}</>:<>{line.slice(0,at)}<span style={{color:C.green}}>{focus}</span>{line.slice(at+focus.length)}</>;
};

const Effects: React.FC<{scene:number}> = ({scene}) => <>
  {scene===0&&<><Sequence from={0} durationInFrames={26} name="急坠掠过" layout="none"><Audio src={staticFile('audio/life-kline/whoosh.wav')} volume={.48}/></Sequence><Sequence from={22} durationInFrames={23} name="低点落定" layout="none"><Audio src={staticFile('audio/life-kline/impact.wav')} volume={.48}/></Sequence></>}
  {scene===1&&<Sequence from={8} durationInFrames={26} name="镜头拉远" layout="none"><Audio src={staticFile('audio/life-kline/whoosh.wav')} volume={.18}/></Sequence>}
  {scene===2&&<><Sequence from={8} durationInFrames={9} name="底层解锁" layout="none"><Audio src={staticFile('audio/life-kline/lock.wav')} volume={.26}/></Sequence><Sequence from={22} durationInFrames={23} name="模块归位" layout="none"><Audio src={staticFile('audio/life-kline/impact.wav')} volume={.24}/></Sequence></>}
  {scene===3&&<Sequence from={36} durationInFrames={15} name="身体稳定" layout="none"><Audio src={staticFile('audio/life-kline/pulse.wav')} volume={.23}/></Sequence>}
  {scene===4&&<><Sequence from={22} durationInFrames={9} name="拼件一" layout="none"><Audio src={staticFile('audio/life-kline/lock.wav')} volume={.22}/></Sequence><Sequence from={33} durationInFrames={9} name="拼件二" layout="none"><Audio src={staticFile('audio/life-kline/lock.wav')} volume={.24}/></Sequence><Sequence from={44} durationInFrames={9} name="拼件三" layout="none"><Audio src={staticFile('audio/life-kline/lock.wav')} volume={.26}/></Sequence><Sequence from={56} durationInFrames={15} name="技能接通" layout="none"><Audio src={staticFile('audio/life-kline/pulse.wav')} volume={.28}/></Sequence></>}
  {scene===5&&<><Sequence from={24} durationInFrames={9} name="资源流入" layout="none"><Audio src={staticFile('audio/life-kline/lock.wav')} volume={.14}/></Sequence><Sequence from={68} durationInFrames={15} name="缓冲形成" layout="none"><Audio src={staticFile('audio/life-kline/pulse.wav')} volume={.2}/></Sequence></>}
  {scene===6&&<><Sequence from={0} durationInFrames={26} name="机会逼近" layout="none"><Audio src={staticFile('audio/life-kline/whoosh.wav')} volume={.4}/></Sequence><Sequence from={30} durationInFrames={23} name="矩阵急刹" layout="none"><Audio src={staticFile('audio/life-kline/impact.wav')} volume={.32}/></Sequence></>}
  {scene===7&&<Sequence from={10} durationInFrames={15} name="终句落定" layout="none"><Audio src={staticFile('audio/life-kline/pulse.wav')} volume={.12}/></Sequence>}
</>;

/** Each scene is a single editable unit; global time keeps particles and glow continuous. */
export const LifeScene: React.FC<{scene:number}> = ({scene}) => {
  const f=useCurrentFrame();
  const shot=timeline.scenes[scene];
  const data=content.scenes[scene];
  const single=scene>=3&&scene<=5;
  const opacity=scene===7?1:1-progress(f,shot.durationInFrames-8,8);
  return <AbsoluteFill style={{color:C.white,fontFamily:C.font,overflow:'hidden'}}>
    <LifeArtwork scene={scene} frame={f} globalFrame={shot.from+f}/>
    <div style={{position:'absolute',left:C.left,top:300,width:C.textWidth,opacity}}>
      {single&&<Lift at={0} duration={12} distance={10}><div style={{fontSize:34,color:C.secondary,letterSpacing:1,marginBottom:32}}>{data.kicker}</div></Lift>}
      {data.lines.map((line,i)=><Lift key={line} at={scene===0?(i===0?-18:12):4+i*7} duration={scene===0?18:14} distance={scene===0?30:18}>
        <div style={{fontSize:single?142:scene===7?91:84,fontWeight:single?800:750,lineHeight:single?1.25:1.47,letterSpacing:single?9:0,whiteSpace:'nowrap',textShadow:`0 5px 35px ${C.black}`}}><Emphasis line={line} focus={data.focus}/></div>
      </Lift>)}
      {single&&<div style={{marginTop:34,display:'flex',gap:12}}>{content.fundamentals.map((_,i)=><div key={i} style={{height:4,width:i===scene-3?72:22,background:i===scene-3?C.green:C.steel}}/>)}</div>}
    </div>
    <Effects scene={scene}/>
  </AbsoluteFill>;
};
