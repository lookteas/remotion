import {lifeListingTheme as C} from '../../../src/config/theme';
import {PaperSheet} from '../../../src/components/material/PaperSheet';
import {lerp} from '../../../src/lib/anim';
import {linear, step} from './ListingChart';

export const ListingMaterials=()=> <defs>
  <linearGradient id="listing-paper" x2=".8" y2="1"><stop stopColor={C.paperLight}/><stop offset=".6" stopColor={C.paper}/><stop offset="1" stopColor={C.edge}/></linearGradient>
  <linearGradient id="listing-bronze" x2=".8" y2="1"><stop stopColor={C.goldLight}/><stop offset=".4" stopColor={C.gold}/><stop offset="1" stopColor={C.soil}/></linearGradient>
  <radialGradient id="listing-light"><stop stopColor={C.gold} stopOpacity=".13"/><stop offset="1" stopColor={C.gold} stopOpacity="0"/></radialGradient>
  <filter id="listing-shadow" x="-30%" y="-40%" width="180%" height="200%"><feDropShadow dx="7" dy="16" stdDeviation="12" floodColor={C.black} floodOpacity=".7"/></filter>
</defs>;

export const Token=({x,y,label,scale=1,opacity=1}:{x:number;y:number;label?:string;scale?:number;opacity?:number})=><g transform={`translate(${x} ${y}) scale(${scale})`} opacity={opacity}>
  <ellipse cy="11" rx="69" ry="35" fill={C.edge}/><ellipse rx="69" ry="35" fill="url(#listing-bronze)" stroke={C.goldLight} strokeWidth="2"/>
  <ellipse rx="59" ry="27" fill="none" stroke={C.edge}/>
  {label&&<text y="9" textAnchor="middle" fill={C.char} fontSize="27" fontWeight="750">{label}</text>}
</g>;

export const RestAndMove=({frame:f}:{frame:number})=>{
  const sleep=step(f,650,780),walk=step(f,785,930),breathe=Math.sin(f*.05)*sleep*2;
  return <g filter="url(#listing-shadow)">
    {/* A pillow and crescent establish sleep directly; no battery or mechanism stands for a body. */}
    <g transform={`translate(-145 -40) rotate(-9) scale(1 ${1-sleep*.06+Math.sin(f*.06)*.012})`}>
      <path d="M-123,-65Q0,-90 123,-65Q104,0 123,68Q0,88 -123,68Q-106,0 -123,-65Z" fill="url(#listing-paper)" stroke={C.edge} strokeWidth="2"/>
      <path d="M-105,-51Q0,-71 105,-51Q92,0 105,54Q0,72 -105,54Q-92,0 -105,-51Z" fill="none" stroke={C.edge} strokeDasharray="3 4"/>
      <path d={`M-70,0Q-5,${22+breathe} 73,0`} fill="none" stroke={C.edge} opacity=".3"/>
    </g>
    <path d="M-170,-228A58,58 0 1 0 -111,-155A52,52 0 0 1 -170,-228" fill="url(#listing-bronze)"/>
    <text x="-145" y="95" textAnchor="middle" fill={C.ivory} fontSize="33">按时睡觉</text>
    {/* The shoe takes successive steps and leaves footprints: activity becomes an observable action. */}
    <g transform={`translate(${145+Math.sin(f*.08)*12*walk} ${Math.max(0,Math.sin(f*.08))*-20*walk}) rotate(${Math.sin(f*.08)*6*walk})`}>
      <path d="M-100,-23L-70,-96L-23,-72L23,-20L89,0Q137,12 130,46L-114,46Q-130,15 -100,-23Z" fill="url(#listing-paper)" stroke={C.edge} strokeWidth="3"/>
      <path d="M-116,40H130V58Q20,77 -114,58Z" fill="url(#listing-bronze)"/>
      <path d="M-40,-63L4,-42M-50,-47L17,-26M-60,-31L31,-11" stroke={C.soil} strokeWidth="5"/>
      <path d="M-90,12Q0,45 114,26" fill="none" stroke={C.edge} strokeWidth="3"/>
    </g>
    <text x="155" y="95" textAnchor="middle" fill={C.ivory} fontSize="33">规律运动</text>
    <path d="M-270,172H270" stroke={C.gold} strokeOpacity=".22"/>
    {Array.from({length:7},(_,i)=><g key={i} opacity={step(f,660+i*38,685+i*38)}>
      <circle cx={-205+i*68} cy="175" r="16" fill={C.gold}/>
      <path d={`M${-213+i*68},175l6,6l11,-13`} fill="none" stroke={C.ink} strokeWidth="3"/>
    </g>)}
    <text y="255" textAnchor="middle" fontSize="40" fill={C.goldLight} opacity={step(f,875,940)}>精力恢复</text>
  </g>;
};

export const Portfolio=({frame:f}:{frame:number})=>{
  const writing=linear(f,1020,1225),done=step(f,1225,1290);
  return <div style={{position:'relative',width:560,height:420}}>
    {[2,1,0].map(i=><div key={i} style={{position:'absolute',left:25+i*12,top:18-i*8,rotate:`${-8+i*4}deg`}}>
      <PaperSheet colors={C} w={275} h={350}>
        <div style={{padding:'38px 35px',fontSize:34,fontWeight:600}}>练习稿</div>
        <svg width="275" height="220" style={{position:'absolute',top:95}}>{Array.from({length:5},(_,j)=><path key={j} d={`M35,${j*32+20}q72,-9 188,0`} fill="none" stroke={C.soil} strokeWidth="3" strokeDasharray="190" strokeDashoffset={190*(1-Math.max(0,Math.min(1,writing*5-j)))}/>)}</svg>
      </PaperSheet>
    </div>)}
    <div style={{position:'absolute',left:lerp(60,255,done),top:lerp(-10,30,done),rotate:`${lerp(-12,7,done)}deg`,opacity:step(f,1120,1170)}}>
      <PaperSheet colors={C} w={285} h={350}>
        <div style={{padding:'35px',fontSize:38,fontWeight:700}}>作品</div>
        <div style={{margin:'0 35px',fontSize:25,lineHeight:1.7}}>解决一个问题<br/>做出一个结果</div>
        <svg width="90" height="90" style={{position:'absolute',right:28,bottom:35,opacity:done}}><circle cx="45" cy="45" r="38" fill="none" stroke={C.bronze} strokeWidth="3"/><path d="M23,46L39,61L67,28" fill="none" stroke={C.bronze} strokeWidth="6"/></svg>
      </PaperSheet>
    </div>
    <div style={{position:'absolute',left:190-writing*85,top:100+writing*155,rotate:'-25deg',opacity:1-step(f,1235,1270)}}><svg width="120" height="30"><path d="M0,5H95L119,15L95,25H0Z" fill={C.gold}/><path d="M102,8L119,15L102,22" fill={C.char}/></svg></div>
    <div style={{position:'absolute',top:385,width:560,textAlign:'center',fontSize:36,color:C.goldLight,opacity:done}}>练习，变成拿得出的作品</div>
  </div>;
};

export const savingsIncome=[1400,1435,1470,1505,1540,1575,1610,1645];
export const savingsOut=[1510,1600,1690,1740];
export const savingsAt=(f:number)=>3+savingsIncome.filter(t=>f>=t+26).length-savingsOut.filter(t=>f>=t).length;
export const LivingReserve=({frame:f}:{frame:number})=>{
  const count=savingsAt(f),stopped=f>=1680;
  return <g>
    <path d="M-265,90V-60Q-265,-97 -225,-97H105V118H-230Q-265,118 -265,90Z" fill={C.soil} stroke={C.gold} strokeWidth="3" filter="url(#listing-shadow)"/>
    <path d="M-244,-78H82V98H-233Q-244,98 -244,82Z" fill={C.char} stroke={C.edge} strokeDasharray="3 5"/>
    <path d="M25,-10H127V58H25Q0,23 25,-10Z" fill="url(#listing-bronze)"/><circle cx="41" cy="24" r="10" fill={C.soil}/>
    <text x="-85" y="-12" textAnchor="middle" fill={C.ivory} fontSize="34">生活备用金</text>
    {Array.from({length:count},(_,i)=><Token key={i} x={-185+(i%4)*64} y={75-Math.floor(i/4)*31} scale={.48}/>)}
    <text x="240" y="-55" textAnchor="middle" fill={C.secondary} fontSize="32">必要支出</text>
    <text x="240" y="-8" textAnchor="middle" fill={C.secondary} fontSize="26">房租 · 吃饭</text>
    <path d="M100,97Q180,130 255,65" fill="none" stroke={C.gold} opacity=".4"/>
    {savingsIncome.map(t=>{const p=linear(f,t,t+26),slot=savingsAt(t+25),x=-185+(slot%4)*64,y=75-Math.floor(slot/4)*31;return p>0&&p<1?<Token key={t} x={lerp(-210,x,p)} y={lerp(-210,y,p)} scale={.48}/>:null;})}
    {savingsOut.map(t=>{const p=linear(f,t,t+36),slot=savingsAt(t-1)-1,x=-185+(slot%4)*64,y=75-Math.floor(slot/4)*31;return p>0&&p<1?<Token key={t} x={lerp(x,260,p)} y={lerp(y,75,p)+Math.sin(p*Math.PI)*50} scale={.48} opacity={1-step(f,t+28,t+36)}/>:null;})}
    <text x="-195" y="-250" textAnchor="middle" fill={C.goldLight} fontSize="30">{stopped?'收入暂时中断':'留下一部分收入'}</text>
    <text y="205" textAnchor="middle" fill={C.goldLight} fontSize="36">{stopped?'仍能支付必要支出':'积攒生活缓冲'}</text>
  </g>;
};

export const ProjectLetter=({frame:f}:{frame:number})=>{
  const show=step(f,1780,1860);
  return <div style={{position:'relative',width:700,height:390}}>
    <div style={{position:'absolute',left:30,top:90,width:640,height:300,background:C.edge,transform:`perspective(1000px) rotateX(${lerp(65,12,show)}deg)`,boxShadow:`0 20px 40px ${C.black}88`}}/>
    <div style={{position:'absolute',left:0,top:lerp(75,0,show)}}><PaperSheet colors={C} w={700} h={360}>
      <div style={{padding:'36px 48px',color:C.char}}>
        <div style={{fontSize:43,fontWeight:700,borderBottom:`1px solid ${C.edge}`,paddingBottom:17}}>新项目邀请</div>
        <div style={{fontSize:26,marginTop:19}}>需要有人：持续投入，把事情做完</div>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:30,marginTop:31}}>{['精力','作品','时间余地'].map((s,i)=><span key={s} style={{opacity:lerp(.35,1,step(f,1900+i*50,1930+i*50))}}>{step(f,1900+i*50,1930+i*50)>.95?'✓ ':''}{s}</span>)}</div>
        <div style={{position:'absolute',bottom:27,right:45,fontSize:27,color:C.bronze}}>接不接，由你决定</div>
      </div>
    </PaperSheet></div>
  </div>;
};
