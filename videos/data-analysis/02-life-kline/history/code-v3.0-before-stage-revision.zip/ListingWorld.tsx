import React from 'react';
import {useCurrentFrame} from 'remotion';
import {lifeListingTheme as C} from '../../../src/config/theme';
import {lerp,rand} from '../../../src/lib/anim';
import {Chart,step} from './ListingChart';
import {ListingMaterials,LivingReserve,Portfolio,ProjectLetter,RestAndMove,Token} from './ListingObjects';

const pose=(f:number,start:number,end:number,x:number)=>{
  const p=step(f,start,end);return {x:lerp(540,x,p),y:lerp(1110,1360,p),s:lerp(1,.31,p)};
};
const HtmlObject=({x,y,scale,width,height,opacity=1,children}:{x:number;y:number;scale:number;width:number;height:number;opacity?:number;children:React.ReactNode})=><div style={{position:'absolute',left:x-width/2,top:y-height/2,width,height,scale:String(scale),opacity,transformOrigin:'center'}}>{children}</div>;

/** One persistent chart and the actual results of self-investment, with no machine chassis. */
export const ListingWorld=()=>{
  const f=useCurrentFrame(),body=pose(f,955,1045,220),skills=pose(f,1310,1400,540),cash=pose(f,1740,1840,860);
  const letterExit=step(f,2170,2370);
  return <>
    <svg width="1080" height="1920" style={{position:'absolute',inset:0}}>
      <ListingMaterials/>
      <rect width="1080" height="1920" fill={C.ink}/>
      <ellipse cx="560" cy="1090" rx="650" ry="800" fill="url(#listing-light)"/>
      {Array.from({length:35},(_,i)=>{const x=rand(i,8)*1080,y=(rand(i,12)*1920-f*(.07+rand(i,6)*.09)+1920)%1920;return <circle key={i} cx={x} cy={y} r={.6+rand(i,3)} fill={C.goldLight} opacity={.03+rand(i,5)*.12}/>;})}
    </svg>
    <Chart frame={f}/>
    <svg width="1080" height="1920" style={{position:'absolute',inset:0,overflow:'visible'}}>
      <g opacity={step(f,240,275)*(1-step(f,400,435))}>
        <path d="M260,1350Q540,1307 820,1350" fill="none" stroke={C.gold} strokeWidth="2"/>
        <text x="540" y="1390" textAnchor="middle" fill={C.goldLight} fontSize="52">低价 ≠ 低价值</text>
      </g>
      {/* Actual input to the metaphor: time, effort, resources. They move into the first activity. */}
      <g opacity={step(f,450,480)*(1-step(f,620,670))}>
        {['时间','精力','资源'].map((label,i)=>{const move=step(f,550+i*15,650+i*7);return <Token key={label} label={label} x={lerp(300+i*240,540,move)} y={lerp(1120,1040,move)} scale={lerp(1.3,.65,move)}/>;})}
        <text x="540" y="1300" textAnchor="middle" fill={C.secondary} fontSize="39">把投入，转回自己身上</text>
      </g>
      <g opacity={step(f,625,670)} transform={`translate(${body.x} ${body.y}) scale(${body.s})`}><RestAndMove frame={f}/></g>
      <g opacity={step(f,1350,1390)} transform={`translate(${cash.x} ${cash.y}) scale(${cash.s})`}><LivingReserve frame={f}/></g>
      <g opacity={step(f,1870,1910)*(1-step(f,2170,2260))}>
        {[220,540,860].map((x,i)=><path key={x} d={`M${x},1275Q${x},1240 ${290+i*240},1215`} fill="none" stroke={C.gold} strokeWidth="2" strokeDasharray="4 5" opacity={step(f,1900+i*50,1930+i*50)}/>)}
      </g>
      <g opacity={step(f,1840,1880)*(1-step(f,2170,2260))}>
        {['精力','作品','备用金 → 时间余地'].map((label,i)=><text key={label} x={220+i*320} y="1490" textAnchor="middle" fill={C.goldLight} fontSize="27">{label}</text>)}
      </g>
      <g opacity={step(f,2310,2370)}>
        <path d="M830,1080Q830,1190 570,1210" fill="none" stroke={C.gold} strokeWidth="2"/>
        <text x="540" y="1250" textAnchor="middle" fill={C.goldLight} fontSize="36">仍在低位，也能开始投入自己</text>
      </g>
    </svg>
    <HtmlObject x={skills.x} y={skills.y} scale={skills.s} width={560} height={420} opacity={step(f,990,1030)}><Portfolio frame={f}/></HtmlObject>
    <HtmlObject x={lerp(540,1150,letterExit)} y={lerp(1080,930,letterExit)} scale={lerp(1,.4,letterExit)} width={700} height={390} opacity={step(f,1770,1820)*(1-letterExit)}><ProjectLetter frame={f}/></HtmlObject>
  </>;
};
