import {loadFont} from '@remotion/fonts';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {lifeKlineTheme as C} from '../../../src/config/theme';
import {Lift} from '../../../src/components/motion/Lift';
import {AssetWorld} from './AssetWorld';
import {ease} from './motion';
import content from './content.json';
import timeline from './timeline.json';

if(typeof document!=='undefined')void loadFont({family:'LifeKlineSans',url:staticFile('fonts/life-kline/NotoSansSC-life-kline.woff2'),weight:'100 900'});
export const DURATION=timeline.scenes.reduce((sum,s)=>sum+s.durationInFrames,0);
const Caption=({scene}:{scene:number})=>{
  const f=useCurrentFrame(),data=content.scenes[scene],duration=timeline.scenes[scene].durationInFrames;
  if(scene>=3&&scene<=5){
    const action=scene===3?'恢复 → 持续供能':scene===4?'练习 → 组装 → 输出':f<280?'流入 / 支出 / 留存':'流入暂停 · 留存支撑支出';
    return <div style={{position:'absolute',top:1490,left:90,width:900,color:C.secondary,fontSize:43,lineHeight:1.5,opacity:ease(f,35,65)*(1-ease(f,duration-24,duration))}}>{action}</div>;
  }
  const opacity=scene===7?1:1-ease(f,duration-24,duration);
  return <div style={{position:'absolute',top:1460,left:90,width:900,color:C.white,opacity,fontSize:scene===0?76:72,fontWeight:750,lineHeight:1.48,letterSpacing:-1,textShadow:`0 4px 24px ${C.black}`}}>
    {data.lines.map((line,i)=><Lift key={line} at={scene===0?18+i*12:i*10} duration={24} distance={22}>
      <div style={{color:i===1?C.green:C.white}}>{line}</div>
    </Lift>)}
  </div>;
};
const contacts:[number,string,number][]=[[88,'impact',.25],[370,'whoosh',.15],[560,'lock',.17],[855,'pulse',.12],[1060,'lock',.26],[1160,'pulse',.15],[1510,'lock',.09],[1570,'lock',.09],[1630,'lock',.09],[1690,'whoosh',.23],[1790,'pulse',.15]];
export default function LifeKline(){
  return <AbsoluteFill style={{background:C.bg,fontFamily:C.font,overflow:'hidden'}}>
    <Sequence from={0} durationInFrames={DURATION} name="同一资产 · 展开内部 → 恢复 → 传动 → 缓冲 → 选择"><AssetWorld/></Sequence>
    {timeline.scenes.map((s,i)=><Sequence key={s.id} from={s.from} durationInFrames={s.durationInFrames} name={`${s.id} ${s.name}`}><Caption scene={i}/></Sequence>)}
    {contacts.map(([at,file,volume],i)=><Sequence key={i} from={at} durationInFrames={30} name={`动作音效 ${file}`}><Audio src={staticFile(`audio/life-kline/${file}.wav`)} volume={volume}/></Sequence>)}
    <div style={{position:'absolute',left:90,top:145,color:C.secondary,fontSize:26,letterSpacing:1}}>{content.disclosure}</div>
  </AbsoluteFill>;
}
